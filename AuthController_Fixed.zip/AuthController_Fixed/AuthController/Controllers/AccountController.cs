using AuthController.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace AuthController.Controllers
{
    public class AccountController : Controller
    {
        // UserManager is a service provided by ASP.NET Core Identity
        // that handles user management operations such as creating, updating, and deleting users.
        private readonly UserManager<IdentityUser> _userManager;
        // SignInManager is a service provided by ASP.NET Core Identity
        // that handles user sign-in and sign-out operations.
        private readonly SignInManager<IdentityUser> _signInManager;

        //Constructor to inject UserManager and SignInManager services
        public AccountController(UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        //This action responds to form submissions(Post reques).
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            //asynchronously creates a new user with the provided email and password.
            //async Task<IActionResult>: Asynchronous action method that returns an View or redirect.

            //here RegisterViewModel is a model class that contains
            //the properties for user registration, such as Email and Password. 
            if (ModelState.IsValid)
                //if(ModelState.IsValid) checks if the form input passes validation rules liek [Required,
                //EmailAddress etc.
                //if Invalid, skips registration and redisplays the form with errors.
            {
                var user = new IdentityUser { UserName = model.Email, Email = model.Email }; // FIX: was Email = model.Password
                //Creates a new IdentityUser object.
                //Sets Username and Email from the form input
                //This is the actual entity stored in AspNetUsers table.
                var result = await _userManager.CreateAsync(user, model.Password);
                //Calls UserManager to create the user in DB.
                //Password is automatically hashed before saving.
                //returns a result object with succeeded or errormessages.
                if (result.Succeeded)
                {
                    //If user creation succeeded.
                    //SignInManager.SignInAsync=>logs the user in immediately.
                    //IsPersistentn:false==>Cookie expiers when browser closes("not remember me").
                    //and Finally redirect to Action
                    await _signInManager.SignInAsync(user, isPersistent: false);
                    return RedirectToAction("Index", "Home");
                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            return View(model);
            //if validation fails or user creation fails redisplay the form 
            //with enterd data +error message.
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        //this method runs when login form is submitted
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            //LoginViewModel collects the users email and password fromt he form..
            //async Task<IActionResult>:Asynchronous action method that returns an View or redirect
            if (ModelState.IsValid)
            {
                var result = await _signInManager.PasswordSignInAsync(model.Email, model.Password, false,false);
                //Calls _signInManager to check credentials:
                //Parameters:
                //model.Email==>Usernmae/email
                //model.Password==>password
                //false:dont remember login after browser closes (not persistent)
                //false:dont lock out user on failure.
                //returns result object with succeeded,failed or Lockeout.
                if (result.Succeeded)
                {
                    return RedirectToAction("Index", "Home");
                    //if login sucessfull redirect to  home/Index page.
                }
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                //in case if login fails redirect to error message to the model state.
                // this message will be shown in the view.
            }
            return View(model);
            //reloads the login view with the enterd data and error messges,

        }

        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
        [Authorize]
        public IActionResult Index()
        {
            return RedirectToAction("Index", "Home");
        }
        [Authorize]
        public IActionResult Dashboard()
        {
            return View();

        }
        /*
         * AuthorizeAttribute: If we have placed [Authorize] above Dashboard
         * it means only logged in users can access it.
         * If someone tries to open Account/Dashboard without logging in they will
         * be redirected to the Login page.
         * 
         * Authentication Middleware:
         * In Program.cs we should make sure we have
         * app.UseAuthentication();
         * app.UseAuthorization();
         * These must be in the pipeline so that it executes in the 
         * 
         */

    }
}
