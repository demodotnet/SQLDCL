﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AuthController.Models
{
    public class AppDbContext:IdentityDbContext<IdentityUser>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        // public DbSet<LoginViewModel> Users { get; set; }
        //public DbSet<RegisterViewModel> RegisteredUsers { get; set; }
        /*
         * After creating Migrations we get the following tables in the database:
         * AspNetUsers:It says that this table is used to 
         * store user information, such as username, email, password hash, and other related data.
         * AspNetRoles: This table is used to store role information, such as role name and description.
         * AspNetUserRoles: This table is used to store the relationship between users and roles.
         * AspNetUserClaims: This table is used to store claims associated with users.
         * AspNetUserLogins: This table is used to store external login information for users.
         * AspNetRoleClaims: This table is used to store claims associated with roles.
         * AspNetUserTokens: This table is used to store refresh tokens for users.
         */
    }
}
