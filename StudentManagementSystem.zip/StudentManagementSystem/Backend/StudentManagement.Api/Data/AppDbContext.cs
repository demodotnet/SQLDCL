using Microsoft.EntityFrameworkCore;
using StudentManagement.Api.Models;

namespace StudentManagement.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Student> Students => Set<Student>();
    public DbSet<Course> Courses => Set<Course>();
    public DbSet<Teacher> Teachers => Set<Teacher>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Student>()
            .HasIndex(s => s.Email)
            .IsUnique();

        // A course cannot be deleted while it still has students
        modelBuilder.Entity<Student>()
            .HasOne(s => s.Course)
            .WithMany(c => c.Students)
            .HasForeignKey(s => s.CourseId)
            .OnDelete(DeleteBehavior.Restrict);

        // Deleting a teacher keeps the course (TeacherId becomes NULL)
        modelBuilder.Entity<Course>()
            .HasOne(c => c.Teacher)
            .WithMany(t => t.Courses)
            .HasForeignKey(c => c.TeacherId)
            .OnDelete(DeleteBehavior.SetNull);

        // Sample data
        modelBuilder.Entity<Teacher>().HasData(
            new Teacher { TeacherId = 1, Name = "Ravi Kumar", Subject = ".NET", Contact = "9876543210" },
            new Teacher { TeacherId = 2, Name = "Sita Devi", Subject = "Angular", Contact = "9123456780" });

        modelBuilder.Entity<Course>().HasData(
            new Course { CourseId = 1, CourseName = ".NET Full Stack", Duration = "6 Months", Fees = 25000, TeacherId = 1 },
            new Course { CourseId = 2, CourseName = "Angular Frontend", Duration = "3 Months", Fees = 15000, TeacherId = 2 });

        modelBuilder.Entity<Student>().HasData(
            new Student { StudentId = 1, Name = "Anil", Age = 21, Email = "anil@example.com", CourseId = 1 },
            new Student { StudentId = 2, Name = "Priya", Age = 22, Email = "priya@example.com", CourseId = 2 });
    }
}
