using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace StudentManagement.Api.Models;

public class Course
{
    public int CourseId { get; set; }

    [Required, MaxLength(100)]
    public string CourseName { get; set; } = string.Empty;

    [MaxLength(50)]
    public string? Duration { get; set; }

    [Column(TypeName = "decimal(18,2)")]
    public decimal Fees { get; set; }

    public int? TeacherId { get; set; }

    [JsonIgnore]
    public Teacher? Teacher { get; set; }

    // One course -> many students
    [JsonIgnore]
    public ICollection<Student> Students { get; set; } = new List<Student>();
}
