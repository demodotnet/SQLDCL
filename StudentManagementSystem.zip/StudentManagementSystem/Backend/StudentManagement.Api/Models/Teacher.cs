using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace StudentManagement.Api.Models;

public class Teacher
{
    public int TeacherId { get; set; }

    [Required, MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required, MaxLength(100)]
    public string Subject { get; set; } = string.Empty;

    [MaxLength(20)]
    public string? Contact { get; set; }

    // One teacher -> many courses
    [JsonIgnore]
    public ICollection<Course> Courses { get; set; } = new List<Course>();
}
