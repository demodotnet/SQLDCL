namespace StudentManagement.Api.Dtos;

public record StudentDto(int StudentId, string Name, int Age, string Email, int CourseId, string? CourseName);

public record CourseDto(int CourseId, string CourseName, string? Duration, decimal Fees,
                        int? TeacherId, string? TeacherName, int StudentCount);

public record CourseCount(string CourseName, int Count);

public record DashboardDto(int TotalStudents, int TotalCourses, int TotalTeachers,
                           List<CourseCount> StudentsPerCourse);
