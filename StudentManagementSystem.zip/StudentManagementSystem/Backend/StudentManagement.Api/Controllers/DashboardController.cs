using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Api.Data;
using StudentManagement.Api.Dtos;

namespace StudentManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly AppDbContext _db;
    public DashboardController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<DashboardDto>> Get()
    {
        var perCourse = await _db.Courses
            .Select(c => new CourseCount(c.CourseName, c.Students.Count))
            .ToListAsync();

        return new DashboardDto(
            await _db.Students.CountAsync(),
            await _db.Courses.CountAsync(),
            await _db.Teachers.CountAsync(),
            perCourse);
    }
}
