using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Api.Data;
using StudentManagement.Api.Dtos;
using StudentManagement.Api.Models;

namespace StudentManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class StudentsController : ControllerBase
{
    private readonly AppDbContext _db;
    public StudentsController(AppDbContext db) => _db = db;

    // GET api/students?search=anil
    [HttpGet]
    public async Task<ActionResult<IEnumerable<StudentDto>>> GetAll([FromQuery] string? search)
    {
        var query = _db.Students.AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
            query = query.Where(s => s.Name.Contains(search) || s.Email.Contains(search));

        var list = await query
            .OrderBy(s => s.StudentId)
            .Select(s => new StudentDto(s.StudentId, s.Name, s.Age, s.Email, s.CourseId,
                                        s.Course != null ? s.Course.CourseName : null))
            .ToListAsync();

        return Ok(list);
    }

    // GET api/students/5
    [HttpGet("{id:int}")]
    public async Task<ActionResult<StudentDto>> GetById(int id)
    {
        var s = await _db.Students.Include(x => x.Course).FirstOrDefaultAsync(x => x.StudentId == id);
        if (s == null) return NotFound();
        return new StudentDto(s.StudentId, s.Name, s.Age, s.Email, s.CourseId, s.Course?.CourseName);
    }

    // POST api/students
    [HttpPost]
    public async Task<ActionResult> Create(Student student)
    {
        if (!await _db.Courses.AnyAsync(c => c.CourseId == student.CourseId))
            return BadRequest(new { message = "Selected course does not exist." });

        if (await _db.Students.AnyAsync(s => s.Email == student.Email))
            return Conflict(new { message = "A student with this email already exists." });

        student.StudentId = 0;
        _db.Students.Add(student);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = student.StudentId }, student);
    }

    // PUT api/students/5
    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Student student)
    {
        if (id != student.StudentId) return BadRequest(new { message = "Id mismatch." });

        var existing = await _db.Students.FindAsync(id);
        if (existing == null) return NotFound();

        if (!await _db.Courses.AnyAsync(c => c.CourseId == student.CourseId))
            return BadRequest(new { message = "Selected course does not exist." });

        if (await _db.Students.AnyAsync(s => s.Email == student.Email && s.StudentId != id))
            return Conflict(new { message = "A student with this email already exists." });

        existing.Name = student.Name;
        existing.Age = student.Age;
        existing.Email = student.Email;
        existing.CourseId = student.CourseId;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    // DELETE api/students/5
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var student = await _db.Students.FindAsync(id);
        if (student == null) return NotFound();

        _db.Students.Remove(student);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
