using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Api.Data;
using StudentManagement.Api.Dtos;
using StudentManagement.Api.Models;

namespace StudentManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CoursesController : ControllerBase
{
    private readonly AppDbContext _db;
    public CoursesController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<CourseDto>>> GetAll()
    {
        var list = await _db.Courses
            .OrderBy(c => c.CourseId)
            .Select(c => new CourseDto(c.CourseId, c.CourseName, c.Duration, c.Fees,
                                       c.TeacherId,
                                       c.Teacher != null ? c.Teacher.Name : null,
                                       c.Students.Count))
            .ToListAsync();
        return Ok(list);
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Course>> GetById(int id)
    {
        var course = await _db.Courses.FindAsync(id);
        return course == null ? NotFound() : course;
    }

    [HttpPost]
    public async Task<ActionResult> Create(Course course)
    {
        course.CourseId = 0;
        _db.Courses.Add(course);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = course.CourseId }, course);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Course course)
    {
        if (id != course.CourseId) return BadRequest(new { message = "Id mismatch." });

        var existing = await _db.Courses.FindAsync(id);
        if (existing == null) return NotFound();

        existing.CourseName = course.CourseName;
        existing.Duration = course.Duration;
        existing.Fees = course.Fees;
        existing.TeacherId = course.TeacherId;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var course = await _db.Courses.FindAsync(id);
        if (course == null) return NotFound();

        if (await _db.Students.AnyAsync(s => s.CourseId == id))
            return BadRequest(new { message = "Cannot delete a course that still has students." });

        _db.Courses.Remove(course);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
