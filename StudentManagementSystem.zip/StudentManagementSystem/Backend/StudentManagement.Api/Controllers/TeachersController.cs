using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentManagement.Api.Data;
using StudentManagement.Api.Models;

namespace StudentManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TeachersController : ControllerBase
{
    private readonly AppDbContext _db;
    public TeachersController(AppDbContext db) => _db = db;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Teacher>>> GetAll() =>
        await _db.Teachers.OrderBy(t => t.TeacherId).ToListAsync();

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Teacher>> GetById(int id)
    {
        var teacher = await _db.Teachers.FindAsync(id);
        return teacher == null ? NotFound() : teacher;
    }

    [HttpPost]
    public async Task<ActionResult> Create(Teacher teacher)
    {
        teacher.TeacherId = 0;
        _db.Teachers.Add(teacher);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = teacher.TeacherId }, teacher);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Teacher teacher)
    {
        if (id != teacher.TeacherId) return BadRequest(new { message = "Id mismatch." });

        var existing = await _db.Teachers.FindAsync(id);
        if (existing == null) return NotFound();

        existing.Name = teacher.Name;
        existing.Subject = teacher.Subject;
        existing.Contact = teacher.Contact;

        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var teacher = await _db.Teachers.FindAsync(id);
        if (teacher == null) return NotFound();

        _db.Teachers.Remove(teacher);
        await _db.SaveChangesAsync();
        return NoContent();
    }
}
