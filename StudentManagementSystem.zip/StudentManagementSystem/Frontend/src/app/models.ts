export interface Student {
  studentId: number;
  name: string;
  age: number;
  email: string;
  courseId: number;
  courseName?: string | null;
}

export interface Course {
  courseId: number;
  courseName: string;
  duration: string | null;
  fees: number;
  teacherId: number | null;
  teacherName?: string | null;
  studentCount?: number;
}

export interface Teacher {
  teacherId: number;
  name: string;
  subject: string;
  contact: string | null;
}

export interface Dashboard {
  totalStudents: number;
  totalCourses: number;
  totalTeachers: number;
  studentsPerCourse: { courseName: string; count: number }[];
}
