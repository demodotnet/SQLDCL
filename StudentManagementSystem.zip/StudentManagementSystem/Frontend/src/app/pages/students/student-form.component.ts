import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { Course, Student } from '../../models';

@Component({
  selector: 'app-student-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="card">
      <h2>{{ id ? 'Edit Student' : 'Add Student' }}</h2>
      <div class="alert" *ngIf="error">{{ error }}</div>

      <form #f="ngForm" (ngSubmit)="save(f.valid === true)">
        <div class="form-row">
          <label>Name</label>
          <input name="name" [(ngModel)]="student.name" required #name="ngModel">
          <div class="error" *ngIf="name.invalid && (name.touched || submitted)">Name is required.</div>
        </div>

        <div class="form-row">
          <label>Age</label>
          <input name="age" type="number" [(ngModel)]="student.age" required min="5" max="100" #age="ngModel">
          <div class="error" *ngIf="age.invalid && (age.touched || submitted)">Age must be between 5 and 100.</div>
        </div>

        <div class="form-row">
          <label>Email</label>
          <input name="email" type="email" [(ngModel)]="student.email" required email #email="ngModel">
          <div class="error" *ngIf="email.invalid && (email.touched || submitted)">Enter a valid email.</div>
        </div>

        <div class="form-row">
          <label>Course</label>
          <select name="courseId" [(ngModel)]="student.courseId" required #course="ngModel">
            <option [ngValue]="0" disabled>-- Select course --</option>
            <option *ngFor="let c of courses" [ngValue]="c.courseId">{{ c.courseName }}</option>
          </select>
          <div class="error" *ngIf="student.courseId === 0 && submitted">Please select a course.</div>
        </div>

        <button class="btn btn-primary" type="submit">Save</button>
        <a class="btn btn-light" routerLink="/students" style="margin-left:8px">Cancel</a>
      </form>
    </div>
  `
})
export class StudentFormComponent implements OnInit {
  id: number | null = null;
  student: Partial<Student> = { name: '', age: 18, email: '', courseId: 0 };
  courses: Course[] = [];
  submitted = false;
  error = '';

  constructor(private api: ApiService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit(): void {
    this.api.getCourses().subscribe(c => (this.courses = c));

    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.id = +idParam;
      this.api.getStudent(this.id).subscribe(s => (this.student = s));
    }
  }

  save(valid: boolean): void {
    this.submitted = true;
    if (!valid || !this.student.courseId) return;

    const request = this.id
      ? this.api.updateStudent(this.id, this.student)
      : this.api.addStudent(this.student);

    request.subscribe({
      next: () => this.router.navigate(['/students']),
      error: err => (this.error = err?.error?.message ?? 'Save failed.')
    });
  }
}
