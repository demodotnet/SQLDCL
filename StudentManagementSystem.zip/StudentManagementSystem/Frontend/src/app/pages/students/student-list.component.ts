import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../services/api.service';
import { Student } from '../../models';

@Component({
  selector: 'app-student-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="card">
      <h2>Students</h2>
      <div class="alert" *ngIf="error">{{ error }}</div>

      <div class="toolbar">
        <input type="text" placeholder="Search by name or email..."
               [(ngModel)]="search" (ngModelChange)="load()">
        <a class="btn btn-primary" routerLink="/students/new">+ Add Student</a>
      </div>

      <table>
        <thead>
          <tr><th>ID</th><th>Name</th><th>Age</th><th>Email</th><th>Course</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <tr *ngFor="let s of students">
            <td>{{ s.studentId }}</td>
            <td>{{ s.name }}</td>
            <td>{{ s.age }}</td>
            <td>{{ s.email }}</td>
            <td>{{ s.courseName }}</td>
            <td class="actions">
              <a class="btn btn-edit" [routerLink]="['/students/edit', s.studentId]">Edit</a>
              <button class="btn btn-danger" (click)="remove(s)">Delete</button>
            </td>
          </tr>
          <tr *ngIf="students.length === 0"><td colspan="6">No students found.</td></tr>
        </tbody>
      </table>
    </div>
  `
})
export class StudentListComponent implements OnInit {
  students: Student[] = [];
  search = '';
  error = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void { this.load(); }

  load(): void {
    this.api.getStudents(this.search).subscribe({
      next: list => { this.students = list; this.error = ''; },
      error: () => (this.error = 'Cannot load students. Is the Web API running?')
    });
  }

  remove(s: Student): void {
    if (!confirm(`Delete student "${s.name}"?`)) return;
    this.api.deleteStudent(s.studentId).subscribe({
      next: () => this.load(),
      error: () => (this.error = 'Delete failed.')
    });
  }
}
