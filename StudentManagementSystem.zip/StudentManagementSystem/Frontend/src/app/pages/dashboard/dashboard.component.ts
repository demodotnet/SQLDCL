import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { Dashboard } from '../../models';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <h2>Dashboard</h2>
    <div class="alert" *ngIf="error">{{ error }}</div>

    <ng-container *ngIf="data">
      <div class="stats">
        <div class="stat"><div class="num">{{ data.totalStudents }}</div>Students</div>
        <div class="stat"><div class="num">{{ data.totalCourses }}</div>Courses</div>
        <div class="stat"><div class="num">{{ data.totalTeachers }}</div>Teachers</div>
      </div>

      <div class="card">
        <h3>Students per course</h3>
        <div class="bar-row" *ngFor="let c of data.studentsPerCourse">
          <div class="bar-label">{{ c.courseName }}</div>
          <div class="bar" [style.width.px]="c.count * 40"></div>
          <div>{{ c.count }}</div>
        </div>
      </div>
    </ng-container>
  `
})
export class DashboardComponent implements OnInit {
  data: Dashboard | null = null;
  error = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.getDashboard().subscribe({
      next: d => (this.data = d),
      error: () => (this.error = 'Cannot reach the API. Is the Web API running on http://localhost:5000 ?')
    });
  }
}
