import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { Teacher } from '../../models';

@Component({
  selector: 'app-teachers',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="card">
      <h2>{{ form.teacherId ? 'Edit Teacher' : 'Add Teacher' }}</h2>
      <div class="alert" *ngIf="error">{{ error }}</div>

      <form class="inline-form" #f="ngForm" (ngSubmit)="save(f.valid === true)">
        <div>
          <label>Name</label>
          <input name="name" [(ngModel)]="form.name" required>
        </div>
        <div>
          <label>Subject</label>
          <input name="subject" [(ngModel)]="form.subject" required>
        </div>
        <div>
          <label>Contact</label>
          <input name="contact" [(ngModel)]="form.contact">
        </div>
        <div class="actions">
          <button class="btn btn-primary" type="submit">Save</button>
          <button class="btn btn-light" type="button" (click)="reset()">Clear</button>
        </div>
      </form>
    </div>

    <div class="card">
      <h2>Teachers</h2>
      <table>
        <thead>
          <tr><th>ID</th><th>Name</th><th>Subject</th><th>Contact</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <tr *ngFor="let t of teachers">
            <td>{{ t.teacherId }}</td>
            <td>{{ t.name }}</td>
            <td>{{ t.subject }}</td>
            <td>{{ t.contact }}</td>
            <td class="actions">
              <button class="btn btn-edit" (click)="edit(t)">Edit</button>
              <button class="btn btn-danger" (click)="remove(t)">Delete</button>
            </td>
          </tr>
          <tr *ngIf="teachers.length === 0"><td colspan="5">No teachers yet.</td></tr>
        </tbody>
      </table>
    </div>
  `
})
export class TeachersComponent implements OnInit {
  teachers: Teacher[] = [];
  form: Partial<Teacher> = this.emptyForm();
  error = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void { this.load(); }

  private emptyForm(): Partial<Teacher> {
    return { name: '', subject: '', contact: '' };
  }

  load(): void {
    this.api.getTeachers().subscribe({
      next: t => (this.teachers = t),
      error: () => (this.error = 'Cannot load teachers. Is the Web API running?')
    });
  }

  edit(t: Teacher): void { this.form = { ...t }; }

  reset(): void { this.form = this.emptyForm(); this.error = ''; }

  save(valid: boolean): void {
    if (!valid) return;
    const request = this.form.teacherId
      ? this.api.updateTeacher(this.form.teacherId, this.form)
      : this.api.addTeacher(this.form);

    request.subscribe({
      next: () => { this.reset(); this.load(); },
      error: err => (this.error = err?.error?.message ?? 'Save failed.')
    });
  }

  remove(t: Teacher): void {
    if (!confirm(`Delete teacher "${t.name}"?`)) return;
    this.api.deleteTeacher(t.teacherId).subscribe({
      next: () => this.load(),
      error: err => (this.error = err?.error?.message ?? 'Delete failed.')
    });
  }
}
