import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { Course, Teacher } from '../../models';

@Component({
  selector: 'app-courses',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="card">
      <h2>{{ form.courseId ? 'Edit Course' : 'Add Course' }}</h2>
      <div class="alert" *ngIf="error">{{ error }}</div>

      <form class="inline-form" #f="ngForm" (ngSubmit)="save(f.valid === true)">
        <div>
          <label>Course name</label>
          <input name="courseName" [(ngModel)]="form.courseName" required>
        </div>
        <div>
          <label>Duration</label>
          <input name="duration" [(ngModel)]="form.duration" placeholder="e.g. 6 Months">
        </div>
        <div>
          <label>Fees</label>
          <input name="fees" type="number" [(ngModel)]="form.fees" min="0" required>
        </div>
        <div>
          <label>Teacher</label>
          <select name="teacherId" [(ngModel)]="form.teacherId">
            <option [ngValue]="null">-- None --</option>
            <option *ngFor="let t of teachers" [ngValue]="t.teacherId">{{ t.name }}</option>
          </select>
        </div>
        <div class="actions">
          <button class="btn btn-primary" type="submit">Save</button>
          <button class="btn btn-light" type="button" (click)="reset()">Clear</button>
        </div>
      </form>
    </div>

    <div class="card">
      <h2>Courses</h2>
      <table>
        <thead>
          <tr><th>ID</th><th>Course</th><th>Duration</th><th>Fees</th><th>Teacher</th><th>Students</th><th>Actions</th></tr>
        </thead>
        <tbody>
          <tr *ngFor="let c of courses">
            <td>{{ c.courseId }}</td>
            <td>{{ c.courseName }}</td>
            <td>{{ c.duration }}</td>
            <td>{{ c.fees | number }}</td>
            <td>{{ c.teacherName }}</td>
            <td>{{ c.studentCount }}</td>
            <td class="actions">
              <button class="btn btn-edit" (click)="edit(c)">Edit</button>
              <button class="btn btn-danger" (click)="remove(c)">Delete</button>
            </td>
          </tr>
          <tr *ngIf="courses.length === 0"><td colspan="7">No courses yet.</td></tr>
        </tbody>
      </table>
    </div>
  `
})
export class CoursesComponent implements OnInit {
  courses: Course[] = [];
  teachers: Teacher[] = [];
  form: Partial<Course> = this.emptyForm();
  error = '';

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.api.getTeachers().subscribe(t => (this.teachers = t));
    this.load();
  }

  private emptyForm(): Partial<Course> {
    return { courseName: '', duration: '', fees: 0, teacherId: null };
  }

  load(): void {
    this.api.getCourses().subscribe({
      next: c => (this.courses = c),
      error: () => (this.error = 'Cannot load courses. Is the Web API running?')
    });
  }

  edit(c: Course): void {
    this.form = { courseId: c.courseId, courseName: c.courseName, duration: c.duration,
                  fees: c.fees, teacherId: c.teacherId };
  }

  reset(): void { this.form = this.emptyForm(); this.error = ''; }

  save(valid: boolean): void {
    if (!valid) return;
    const request = this.form.courseId
      ? this.api.updateCourse(this.form.courseId, this.form)
      : this.api.addCourse(this.form);

    request.subscribe({
      next: () => { this.reset(); this.load(); },
      error: err => (this.error = err?.error?.message ?? 'Save failed.')
    });
  }

  remove(c: Course): void {
    if (!confirm(`Delete course "${c.courseName}"?`)) return;
    this.api.deleteCourse(c.courseId).subscribe({
      next: () => { this.error = ''; this.load(); },
      error: err => (this.error = err?.error?.message ?? 'Delete failed.')
    });
  }
}
