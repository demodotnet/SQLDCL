import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Course, Dashboard, Student, Teacher } from '../models';

// Must match the applicationUrl in the Web API's launchSettings.json
const API = 'http://localhost:5000/api';

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}

  // ---- Students ----
  getStudents(search = ''): Observable<Student[]> {
    let params = new HttpParams();
    if (search) params = params.set('search', search);
    return this.http.get<Student[]>(`${API}/students`, { params });
  }
  getStudent(id: number): Observable<Student> {
    return this.http.get<Student>(`${API}/students/${id}`);
  }
  addStudent(s: Partial<Student>): Observable<unknown> {
    return this.http.post(`${API}/students`, s);
  }
  updateStudent(id: number, s: Partial<Student>): Observable<unknown> {
    return this.http.put(`${API}/students/${id}`, s);
  }
  deleteStudent(id: number): Observable<unknown> {
    return this.http.delete(`${API}/students/${id}`);
  }

  // ---- Courses ----
  getCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(`${API}/courses`);
  }
  addCourse(c: Partial<Course>): Observable<unknown> {
    return this.http.post(`${API}/courses`, c);
  }
  updateCourse(id: number, c: Partial<Course>): Observable<unknown> {
    return this.http.put(`${API}/courses/${id}`, c);
  }
  deleteCourse(id: number): Observable<unknown> {
    return this.http.delete(`${API}/courses/${id}`);
  }

  // ---- Teachers ----
  getTeachers(): Observable<Teacher[]> {
    return this.http.get<Teacher[]>(`${API}/teachers`);
  }
  addTeacher(t: Partial<Teacher>): Observable<unknown> {
    return this.http.post(`${API}/teachers`, t);
  }
  updateTeacher(id: number, t: Partial<Teacher>): Observable<unknown> {
    return this.http.put(`${API}/teachers/${id}`, t);
  }
  deleteTeacher(id: number): Observable<unknown> {
    return this.http.delete(`${API}/teachers/${id}`);
  }

  // ---- Dashboard ----
  getDashboard(): Observable<Dashboard> {
    return this.http.get<Dashboard>(`${API}/dashboard`);
  }
}
