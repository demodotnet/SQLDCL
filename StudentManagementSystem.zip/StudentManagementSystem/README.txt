Student Management System  (ASP.NET Core Web API + Angular + SQL Server)

1. Backend:  open Backend/StudentManagement.Api in Visual Studio 2022 (.NET 8)
             Package Manager Console:  Add-Migration InitialCreate   then   Update-Database
             Press F5  ->  http://localhost:5000/swagger
2. Frontend: cd Frontend  ->  npm install  ->  ng serve  ->  http://localhost:4200
3. Database: created by the migration (or run Database/StudentManagementDb.sql instead)

Full explanation: see Student_Management_System_Step_by_Step_Guide.docx
