-- Student Management System - SQL Server script
-- Use this ONLY if you do not want to use EF Core migrations.
-- (If you run "dotnet ef database update", you do not need this file.)

IF DB_ID('StudentManagementDb') IS NULL
    CREATE DATABASE StudentManagementDb;
GO

USE StudentManagementDb;
GO

CREATE TABLE Teachers (
    TeacherId INT IDENTITY(1,1) PRIMARY KEY,
    Name      NVARCHAR(100) NOT NULL,
    Subject   NVARCHAR(100) NOT NULL,
    Contact   NVARCHAR(20)  NULL
);

CREATE TABLE Courses (
    CourseId   INT IDENTITY(1,1) PRIMARY KEY,
    CourseName NVARCHAR(100) NOT NULL,
    Duration   NVARCHAR(50)  NULL,
    Fees       DECIMAL(18,2) NOT NULL DEFAULT 0,
    TeacherId  INT NULL,
    CONSTRAINT FK_Courses_Teachers FOREIGN KEY (TeacherId)
        REFERENCES Teachers(TeacherId) ON DELETE SET NULL
);

CREATE TABLE Students (
    StudentId INT IDENTITY(1,1) PRIMARY KEY,
    Name      NVARCHAR(100) NOT NULL,
    Age       INT NOT NULL,
    Email     NVARCHAR(150) NOT NULL,
    CourseId  INT NOT NULL,
    CONSTRAINT FK_Students_Courses FOREIGN KEY (CourseId)
        REFERENCES Courses(CourseId),
    CONSTRAINT UQ_Students_Email UNIQUE (Email)
);
GO

INSERT INTO Teachers (Name, Subject, Contact) VALUES
('Ravi Kumar', '.NET', '9876543210'),
('Sita Devi', 'Angular', '9123456780');

INSERT INTO Courses (CourseName, Duration, Fees, TeacherId) VALUES
('.NET Full Stack', '6 Months', 25000, 1),
('Angular Frontend', '3 Months', 15000, 2);

INSERT INTO Students (Name, Age, Email, CourseId) VALUES
('Anil', 21, 'anil@example.com', 1),
('Priya', 22, 'priya@example.com', 2);
GO

-- Useful queries
SELECT s.StudentId, s.Name, s.Email, c.CourseName, t.Name AS TeacherName
FROM Students s
JOIN Courses c ON c.CourseId = s.CourseId
LEFT JOIN Teachers t ON t.TeacherId = c.TeacherId;
