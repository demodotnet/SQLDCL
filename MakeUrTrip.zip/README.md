# MakeUrTrip – Travel booking app (MakeMyTrip style)

**Backend:** ASP.NET Core 8 Web API + EF Core + SQLite + JWT auth  
**Frontend:** Angular 17 (standalone components)  
**Database:** SQLite file `makeurtrip.db` – created and seeded automatically on first run  
(an equivalent SQL Server script is in `database/schema-sqlserver.sql`)

## Features
- Register / login (JWT, BCrypt password hashing)
- Search **flights**, **hotels**, **buses** (sorting, swap cities, date pickers)
- Booking flow with traveller details, fare summary, simulated payment
- My Bookings page with booking reference and cancellation
- Seed data: 10 cities, ~400 flights, 40 hotels, ~100 buses
- Swagger UI at http://localhost:5000/swagger

## Prerequisites
- .NET 8 SDK  •  Node.js 18+ (20 recommended)

## Run the backend
```bash
cd backend/MakeUrTrip.Api
dotnet restore
dotnet run
```
API: http://localhost:5000  (Swagger: http://localhost:5000/swagger)

## Run the frontend
```bash
cd frontend
npm install
npm start
```
Open http://localhost:4200

> API URL is set in `frontend/src/app/core/api.service.ts` (`API_URL`).
> CORS origin is set in `backend/MakeUrTrip.Api/appsettings.json`.

## API overview
| Method | Endpoint | Notes |
|---|---|---|
| POST | /api/auth/register, /api/auth/login | returns JWT |
| GET | /api/flights/search?from=&to=&date= | |
| GET | /api/hotels/search?city= | |
| GET | /api/buses/search?from=&to=&date= | bus routes: Hyderabad⇄Bengaluru/Chennai/Pune/Mumbai, Bengaluru⇄Chennai/Goa/Kochi, Mumbai⇄Pune/Goa, Delhi⇄Jaipur, Chennai⇄Kochi, Pune⇄Goa |
| POST | /api/bookings | auth required |
| GET | /api/bookings | my bookings |
| POST | /api/bookings/{id}/cancel | |

## Switch to SQL Server
1. `dotnet add package Microsoft.EntityFrameworkCore.SqlServer` (remove the Sqlite package)
2. In `Program.cs` use `o.UseSqlServer(...)`, and set the connection string in `appsettings.json`.
3. Delete the `EnsureCreated` line if you prefer running the SQL script instead.

## Tests ideas / next steps
Seat selection, payment gateway (Razorpay), round trips, filters, email confirmation, admin panel.
