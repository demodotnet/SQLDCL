import { Routes } from '@angular/router';
import { authGuard } from './core/auth.guard';
import { HomeComponent } from './pages/home.component';
import { FlightsComponent } from './pages/flights.component';
import { HotelsComponent } from './pages/hotels.component';
import { BusesComponent } from './pages/buses.component';
import { BookComponent } from './pages/book.component';
import { MyBookingsComponent } from './pages/my-bookings.component';
import { LoginComponent } from './pages/login.component';
import { RegisterComponent } from './pages/register.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'flights', component: FlightsComponent },
  { path: 'hotels', component: HotelsComponent },
  { path: 'buses', component: BusesComponent },
  { path: 'book/:type/:id', component: BookComponent, canActivate: [authGuard] },
  { path: 'my-bookings', component: MyBookingsComponent, canActivate: [authGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: '**', redirectTo: '' }
];
