import { Component, Input, OnChanges, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../core/api.service';
import { isoDate } from '../core/utils';

@Component({
  selector: 'app-search-box',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="search-card">
      <div class="tabs">
        <button [class.active]="tab() === 'flights'" (click)="tab.set('flights')">✈️ Flights</button>
        <button [class.active]="tab() === 'hotels'" (click)="tab.set('hotels')">🏨 Hotels</button>
        <button [class.active]="tab() === 'buses'" (click)="tab.set('buses')">🚌 Buses</button>
      </div>

      <datalist id="cities">
        @for (c of cities(); track c) { <option [value]="c"></option> }
      </datalist>

      @if (tab() === 'flights') {
        <div class="fields">
          <label>From<input list="cities" [(ngModel)]="m.from" placeholder="Hyderabad"></label>
          <button class="swap" (click)="swap()" title="Swap">⇄</button>
          <label>To<input list="cities" [(ngModel)]="m.to" placeholder="Mumbai"></label>
          <label>Departure<input type="date" [min]="today" [(ngModel)]="m.date"></label>
          <label>Travellers<input type="number" min="1" max="9" [(ngModel)]="m.pax"></label>
          <button class="btn btn-primary btn-lg" (click)="search()">SEARCH</button>
        </div>
      }
      @if (tab() === 'hotels') {
        <div class="fields">
          <label>City<input list="cities" [(ngModel)]="m.city" placeholder="Goa"></label>
          <label>Check-in<input type="date" [min]="today" [(ngModel)]="m.checkIn"></label>
          <label>Check-out<input type="date" [min]="m.checkIn" [(ngModel)]="m.checkOut"></label>
          <label>Rooms<input type="number" min="1" max="5" [(ngModel)]="m.rooms"></label>
          <label>Guests<input type="number" min="1" max="12" [(ngModel)]="m.guests"></label>
          <button class="btn btn-primary btn-lg" (click)="search()">SEARCH</button>
        </div>
      }
      @if (tab() === 'buses') {
        <div class="fields">
          <label>From<input list="cities" [(ngModel)]="m.from" placeholder="Hyderabad"></label>
          <button class="swap" (click)="swap()" title="Swap">⇄</button>
          <label>To<input list="cities" [(ngModel)]="m.to" placeholder="Bengaluru"></label>
          <label>Travel date<input type="date" [min]="today" [(ngModel)]="m.date"></label>
          <label>Seats<input type="number" min="1" max="6" [(ngModel)]="m.pax"></label>
          <button class="btn btn-primary btn-lg" (click)="search()">SEARCH</button>
        </div>
      }
      @if (error()) { <p class="error">{{ error() }}</p> }
    </div>
  `
})
export class SearchBoxComponent implements OnInit, OnChanges {
  @Input() initialTab: 'flights' | 'hotels' | 'buses' = 'flights';
  @Input() values: any = {};

  private router = inject(Router);
  private api = inject(ApiService);

  tab = signal<'flights' | 'hotels' | 'buses'>('flights');
  cities = signal<string[]>([]);
  error = signal('');
  today = isoDate();
  m: any = { from: 'Hyderabad', to: 'Mumbai', date: isoDate(1), pax: 1, city: 'Goa',
             checkIn: isoDate(1), checkOut: isoDate(3), rooms: 1, guests: 2 };

  ngOnInit() {
    this.tab.set(this.initialTab);
    this.api.cities().subscribe({ next: c => this.cities.set(c), error: () => {} });
  }
  ngOnChanges() { if (this.values) Object.assign(this.m, this.values); }

  swap() { [this.m.from, this.m.to] = [this.m.to, this.m.from]; }

  search() {
    this.error.set('');
    const m = this.m;
    if (this.tab() === 'hotels') {
      if (!m.city || !m.checkIn || !m.checkOut) return this.error.set('Please fill city and dates.');
      if (m.checkOut <= m.checkIn) return this.error.set('Check-out must be after check-in.');
      this.router.navigate(['/hotels'], { queryParams: { city: m.city, checkIn: m.checkIn, checkOut: m.checkOut, rooms: m.rooms, guests: m.guests } });
      return;
    }
    if (!m.from || !m.to || !m.date) return this.error.set('Please fill from, to and date.');
    if (m.from.trim().toLowerCase() === m.to.trim().toLowerCase()) return this.error.set('From and To cannot be the same.');
    this.router.navigate([this.tab()], { queryParams: { from: m.from, to: m.to, date: m.date, pax: m.pax } });
  }
}
