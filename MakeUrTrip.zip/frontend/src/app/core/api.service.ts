import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Booking, Bus, CreateBooking, Flight, Hotel } from './models';

export const API_URL = 'http://localhost:5000/api';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);

  cities() { return this.http.get<string[]>(`${API_URL}/lookup/cities`); }

  searchFlights(from: string, to: string, date: string) {
    return this.http.get<Flight[]>(`${API_URL}/flights/search`, { params: { from, to, date } });
  }
  getFlight(id: number, date: string) { return this.http.get<Flight>(`${API_URL}/flights/${id}`, { params: { date } }); }

  searchHotels(city: string) { return this.http.get<Hotel[]>(`${API_URL}/hotels/search`, { params: { city } }); }
  getHotel(id: number) { return this.http.get<Hotel>(`${API_URL}/hotels/${id}`); }

  searchBuses(from: string, to: string, date: string) {
    return this.http.get<Bus[]>(`${API_URL}/buses/search`, { params: { from, to, date } });
  }
  getBus(id: number, date: string) { return this.http.get<Bus>(`${API_URL}/buses/${id}`, { params: { date } }); }

  createBooking(b: CreateBooking) { return this.http.post<Booking>(`${API_URL}/bookings`, b); }
  myBookings() { return this.http.get<Booking[]>(`${API_URL}/bookings`); }
  cancelBooking(id: number) { return this.http.post<Booking>(`${API_URL}/bookings/${id}/cancel`, {}); }
}
