export interface Flight { id: number; airline: string; flightNumber: string; fromCity: string; fromCode: string;
  toCity: string; toCode: string; departure: string; arrival: string; durationMinutes: number; price: number; stops: number; }
export interface Hotel { id: number; name: string; city: string; address: string; stars: number; rating: number;
  pricePerNight: number; amenities: string; imageUrl: string; }
export interface Bus { id: number; operator: string; busType: string; fromCity: string; toCity: string;
  departure: string; arrival: string; durationMinutes: number; price: number; seatsAvailable: number; }
export interface Traveller { name: string; age: number; gender: string; }
export interface CreateBooking { type: string; itemId: number; travelDate: string; endDate?: string | null; quantity: number;
  passengers: Traveller[]; contactEmail: string; contactPhone: string; paymentMethod: string; }
export interface Booking { id: number; bookingRef: string; type: string; title: string; subtitle: string; travelDate: string;
  endDate?: string | null; quantity: number; totalAmount: number; status: string; paymentMethod: string; bookedAt: string;
  passengers: Traveller[]; }
export interface AuthResponse { token: string; userId: number; fullName: string; email: string; }
