import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';
import { API_URL } from './api.service';
import { AuthResponse } from './models';

const KEY = 'makeurtrip_auth';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  user = signal<AuthResponse | null>(this.load());

  private load(): AuthResponse | null {
    try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { return null; }
  }
  token(): string | null { return this.user()?.token ?? null; }

  login(email: string, password: string) {
    return this.http.post<AuthResponse>(`${API_URL}/auth/login`, { email, password }).pipe(tap(r => this.save(r)));
  }
  register(fullName: string, email: string, phone: string, password: string) {
    return this.http.post<AuthResponse>(`${API_URL}/auth/register`, { fullName, email, phone, password }).pipe(tap(r => this.save(r)));
  }
  private save(r: AuthResponse) { localStorage.setItem(KEY, JSON.stringify(r)); this.user.set(r); }
  logout() { localStorage.removeItem(KEY); this.user.set(null); this.router.navigate(['/']); }
}
