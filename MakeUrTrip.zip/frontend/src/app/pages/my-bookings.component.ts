import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DatePipe, DecimalPipe } from '@angular/common';
import { ApiService } from '../core/api.service';
import { Booking } from '../core/models';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [RouterLink, DatePipe, DecimalPipe],
  template: `
    <div class="container section">
      <h2>My Bookings</h2>
      @if (newRef) { <div class="success">🎉 Booking confirmed! Your reference is <b>{{ newRef }}</b>.</div> }
      @if (loading()) { <p class="muted">Loading…</p> }
      @else if (bookings().length === 0) { <p class="muted">No bookings yet. <a routerLink="/">Start planning a trip</a>.</p> }
      @else {
        @for (b of bookings(); track b.id) {
          <div class="card booking" [class.cancelled]="b.status === 'Cancelled'">
            <div>
              <span class="badge">{{ b.type }}</span>
              <h3>{{ b.title }}</h3>
              <p>{{ b.subtitle }}</p>
              <p class="muted">
                {{ b.travelDate | date:'dd MMM yyyy' }}@if (b.endDate) { → {{ b.endDate | date:'dd MMM yyyy' }} }
                • Ref <b>{{ b.bookingRef }}</b> • Booked {{ b.bookedAt | date:'dd MMM yyyy, HH:mm' }}
              </p>
              <p class="muted">{{ b.type === 'Hotel' ? 'Guests' : 'Travellers' }}:
                @for (p of b.passengers; track $index) { {{ p.name }} ({{ p.age }}){{ $last ? '' : ', ' }} }
              </p>
            </div>
            <div class="r-price">
              <b>₹{{ b.totalAmount | number:'1.0-0' }}</b>
              <small class="status" [class.bad]="b.status === 'Cancelled'">{{ b.status }}</small>
              @if (b.status === 'Confirmed') { <button class="btn btn-outline" (click)="cancel(b)">Cancel</button> }
            </div>
          </div>
        }
      }
    </div>
  `
})
export class MyBookingsComponent implements OnInit {
  private api = inject(ApiService);
  private route = inject(ActivatedRoute);
  bookings = signal<Booking[]>([]);
  loading = signal(true);
  newRef = '';

  ngOnInit() {
    this.newRef = this.route.snapshot.queryParams['new'] || '';
    this.load();
  }
  load() {
    this.api.myBookings().subscribe({
      next: r => { this.bookings.set(r); this.loading.set(false); },
      error: () => this.loading.set(false)
    });
  }
  cancel(b: Booking) {
    if (!confirm(`Cancel booking ${b.bookingRef}?`)) return;
    this.api.cancelBooking(b.id).subscribe(() => this.load());
  }
}
