import { Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="auth-box card">
      <h2>Login</h2>
      <input type="email" placeholder="Email" [(ngModel)]="email" name="email" (keyup.enter)="submit()">
      <input type="password" placeholder="Password" [(ngModel)]="password" name="password" (keyup.enter)="submit()">
      @if (error()) { <p class="error">{{ error() }}</p> }
      <button class="btn btn-primary btn-lg" [disabled]="busy()" (click)="submit()">LOGIN</button>
      <p class="muted">New here? <a routerLink="/register">Create an account</a></p>
    </div>
  `
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  email = ''; password = '';
  error = signal(''); busy = signal(false);

  submit() {
    if (!this.email || !this.password) return this.error.set('Enter email and password.');
    this.busy.set(true); this.error.set('');
    this.auth.login(this.email, this.password).subscribe({
      next: () => this.router.navigateByUrl(this.route.snapshot.queryParams['returnUrl'] || '/'),
      error: e => { this.error.set(e?.error?.message || 'Login failed.'); this.busy.set(false); }
    });
  }
}
