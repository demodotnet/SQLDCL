import { Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="auth-box card">
      <h2>Create account</h2>
      <input placeholder="Full name" [(ngModel)]="fullName" name="fullName">
      <input type="email" placeholder="Email" [(ngModel)]="email" name="email">
      <input placeholder="Phone" [(ngModel)]="phone" name="phone">
      <input type="password" placeholder="Password (min 6 characters)" [(ngModel)]="password" name="password">
      @if (error()) { <p class="error">{{ error() }}</p> }
      <button class="btn btn-primary btn-lg" [disabled]="busy()" (click)="submit()">SIGN UP</button>
      <p class="muted">Already registered? <a routerLink="/login">Login</a></p>
    </div>
  `
})
export class RegisterComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  fullName = ''; email = ''; phone = ''; password = '';
  error = signal(''); busy = signal(false);

  submit() {
    if (!this.fullName || !this.email || this.password.length < 6) return this.error.set('Fill all fields (password min 6 chars).');
    this.busy.set(true); this.error.set('');
    this.auth.register(this.fullName, this.email, this.phone, this.password).subscribe({
      next: () => this.router.navigate(['/']),
      error: e => {
        const msg = e?.error?.message || (e?.error?.errors ? 'Please check your details.' : 'Registration failed.');
        this.error.set(msg); this.busy.set(false);
      }
    });
  }
}
