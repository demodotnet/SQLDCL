import { Component, inject } from '@angular/core';
import { Router } from '@angular/router';
import { SearchBoxComponent } from '../shared/search-box.component';
import { isoDate } from '../core/utils';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [SearchBoxComponent],
  template: `
    <section class="hero">
      <div class="container">
        <h1>Plan your next trip with MakeUrTrip</h1>
        <p>Book flights, hotels and buses at the best prices</p>
        <app-search-box />
      </div>
    </section>
    <section class="container section">
      <h2>Popular destinations</h2>
      <div class="grid">
        @for (d of destinations; track d.city) {
          <div class="dest" (click)="explore(d.city)">
            <img [src]="'https://picsum.photos/seed/' + d.city + 'x/400/260'" [alt]="d.city">
            <div class="dest-info"><b>{{ d.city }}</b><span>{{ d.tag }}</span></div>
          </div>
        }
      </div>
    </section>
    <section class="container section">
      <h2>Why MakeUrTrip?</h2>
      <div class="grid features">
        <div class="card"><h3>💸 Best price</h3><p>Compare fares across airlines, hotels and bus operators.</p></div>
        <div class="card"><h3>⚡ Instant confirmation</h3><p>Get your booking reference as soon as you pay.</p></div>
        <div class="card"><h3>🛡️ Easy cancellation</h3><p>Manage and cancel trips from My Bookings.</p></div>
      </div>
    </section>
  `
})
export class HomeComponent {
  private router = inject(Router);
  destinations = [
    { city: 'Goa', tag: 'Beaches & nightlife' }, { city: 'Jaipur', tag: 'Royal heritage' },
    { city: 'Kochi', tag: 'Backwaters' }, { city: 'Mumbai', tag: 'City that never sleeps' },
    { city: 'Delhi', tag: 'History & food' }, { city: 'Bengaluru', tag: 'Garden city' }
  ];
  explore(city: string) {
    this.router.navigate(['/hotels'], { queryParams: { city, checkIn: isoDate(1), checkOut: isoDate(3), rooms: 1, guests: 2 } });
  }
}
