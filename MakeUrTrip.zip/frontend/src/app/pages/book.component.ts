import { Component, OnInit, inject, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe, DecimalPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../core/api.service';
import { AuthService } from '../core/auth.service';
import { Traveller } from '../core/models';
import { duration, nightsBetween } from '../core/utils';

@Component({
  selector: 'app-book',
  standalone: true,
  imports: [FormsModule, DatePipe, DecimalPipe],
  template: `
    <div class="container section">
      <h2>Review & Book</h2>
      @if (loading()) { <p class="muted">Loading…</p> }
      @else if (!item) { <p class="error">{{ error() || 'Item not found.' }}</p> }
      @else {
        <div class="book-layout">
          <div>
            <div class="card">
              <h3>Trip summary</h3>
              @if (type === 'flight') {
                <p><b>{{ item.airline }} {{ item.flightNumber }}</b></p>
                <p>{{ item.fromCity }} ({{ item.fromCode }}) → {{ item.toCity }} ({{ item.toCode }})</p>
                <p>{{ item.departure | date:'EEE, dd MMM yyyy, HH:mm' }} – {{ item.arrival | date:'HH:mm' }} • {{ dur(item.durationMinutes) }}</p>
              }
              @if (type === 'bus') {
                <p><b>{{ item.operator }}</b> ({{ item.busType }})</p>
                <p>{{ item.fromCity }} → {{ item.toCity }}</p>
                <p>{{ item.departure | date:'EEE, dd MMM yyyy, HH:mm' }} • {{ dur(item.durationMinutes) }}</p>
              }
              @if (type === 'hotel') {
                <p><b>{{ item.name }}</b> {{ '★'.repeat(item.stars) }}</p>
                <p>{{ item.address }}</p>
                <p>Check-in {{ q.date }} → Check-out {{ q.endDate }} • {{ nights }} night(s) • {{ qty }} room(s)</p>
              }
            </div>

            <div class="card">
              <h3>{{ type === 'hotel' ? 'Guest details' : 'Traveller details' }}</h3>
              @for (p of passengers; track $index) {
                <div class="pax-row">
                  <input placeholder="Full name" [(ngModel)]="p.name" [name]="'n' + $index">
                  <input type="number" min="1" max="120" placeholder="Age" [(ngModel)]="p.age" [name]="'a' + $index">
                  <select [(ngModel)]="p.gender" [name]="'g' + $index">
                    <option>Male</option><option>Female</option><option>Other</option>
                  </select>
                </div>
              }
            </div>

            <div class="card">
              <h3>Contact & payment</h3>
              <div class="pax-row">
                <input type="email" placeholder="Email" [(ngModel)]="contactEmail" name="email">
                <input placeholder="Phone" [(ngModel)]="contactPhone" name="phone">
              </div>
              <div class="pay">
                @for (m of ['UPI', 'Credit/Debit Card', 'Net Banking', 'Pay at Counter']; track m) {
                  <label><input type="radio" name="pay" [value]="m" [(ngModel)]="payment"> {{ m }}</label>
                }
              </div>
              <p class="muted">This is a demo – no real payment is taken.</p>
            </div>
          </div>

          <aside class="card fare">
            <h3>Fare summary</h3>
            <div class="row"><span>{{ type === 'hotel' ? '₹' + (item.pricePerNight | number:'1.0-0') + ' × ' + nights + ' night(s) × ' + qty + ' room(s)' : '₹' + (item.price | number:'1.0-0') + ' × ' + qty }}</span></div>
            <div class="row total"><span>Total</span><b>₹{{ total | number:'1.0-0' }}</b></div>
            @if (error()) { <p class="error">{{ error() }}</p> }
            <button class="btn btn-primary btn-lg" [disabled]="submitting()" (click)="submit()">
              {{ submitting() ? 'Booking…' : 'PAY & CONFIRM' }}
            </button>
          </aside>
        </div>
      }
    </div>
  `
})
export class BookComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private api = inject(ApiService);
  private auth = inject(AuthService);

  type = '';
  id = 0;
  q: any = {};
  qty = 1;
  nights = 1;
  item: any = null;
  loading = signal(true);
  submitting = signal(false);
  error = signal('');
  passengers: Traveller[] = [];
  contactEmail = '';
  contactPhone = '';
  payment = 'UPI';
  dur = duration;

  get total(): number {
    if (!this.item) return 0;
    return this.type === 'hotel' ? this.item.pricePerNight * this.nights * this.qty : this.item.price * this.qty;
  }

  ngOnInit() {
    this.type = this.route.snapshot.paramMap.get('type') || '';
    this.id = +(this.route.snapshot.paramMap.get('id') || 0);
    this.q = this.route.snapshot.queryParams;
    this.qty = +this.q.qty || 1;
    const count = this.type === 'hotel' ? (+this.q.guests || this.qty) : this.qty;
    this.passengers = Array.from({ length: count }, () => ({ name: '', age: 25, gender: 'Male' }));
    this.contactEmail = this.auth.user()?.email ?? '';
    if (this.type === 'hotel') this.nights = Math.max(1, nightsBetween(this.q.date, this.q.endDate));

    const done = { next: (r: any) => { this.item = r; this.loading.set(false); },
                   error: () => { this.error.set('Could not load details.'); this.loading.set(false); } };
    if (this.type === 'flight') this.api.getFlight(this.id, this.q.date).subscribe(done);
    else if (this.type === 'bus') this.api.getBus(this.id, this.q.date).subscribe(done);
    else if (this.type === 'hotel') this.api.getHotel(this.id).subscribe(done);
    else { this.loading.set(false); }
  }

  submit() {
    this.error.set('');
    if (this.passengers.some(p => !p.name.trim() || !p.age)) return this.error.set('Please fill in all traveller names and ages.');
    if (!this.contactEmail || !this.contactPhone) return this.error.set('Please enter contact email and phone.');
    this.submitting.set(true);
    this.api.createBooking({
      type: this.type, itemId: this.id, travelDate: this.q.date, endDate: this.type === 'hotel' ? this.q.endDate : null,
      quantity: this.qty, passengers: this.passengers, contactEmail: this.contactEmail,
      contactPhone: this.contactPhone, paymentMethod: this.payment
    }).subscribe({
      next: b => this.router.navigate(['/my-bookings'], { queryParams: { new: b.bookingRef } }),
      error: e => { this.error.set(e?.error?.message || 'Booking failed. Please try again.'); this.submitting.set(false); }
    });
  }
}
