import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DatePipe, DecimalPipe } from '@angular/common';
import { ApiService } from '../core/api.service';
import { Flight } from '../core/models';
import { duration, isoDate } from '../core/utils';
import { SearchBoxComponent } from '../shared/search-box.component';

@Component({
  selector: 'app-flights',
  standalone: true,
  imports: [SearchBoxComponent, RouterLink, DatePipe, DecimalPipe],
  template: `
    <section class="hero small"><div class="container"><app-search-box initialTab="flights" [values]="params" /></div></section>
    <div class="container section">
      @if (loading()) { <p class="muted">Searching flights…</p> }
      @else if (!searched) { <p class="muted">Enter your route above to search flights.</p> }
      @else if (error()) { <p class="error">{{ error() }}</p> }
      @else if (flights().length === 0) { <p class="muted">No flights found for this route.</p> }
      @else {
        <div class="result-head">
          <h2>{{ params.from }} → {{ params.to }} <small>({{ flights().length }} flights)</small></h2>
          <div class="sort">Sort:
            <button [class.active]="sort() === 'price'" (click)="sort.set('price')">Cheapest</button>
            <button [class.active]="sort() === 'time'" (click)="sort.set('time')">Earliest</button>
            <button [class.active]="sort() === 'duration'" (click)="sort.set('duration')">Fastest</button>
          </div>
        </div>
        @for (f of sorted(); track f.id) {
          <div class="result card">
            <div class="r-main"><b>{{ f.airline }}</b><small>{{ f.flightNumber }}</small></div>
            <div class="r-time"><b>{{ f.departure | date:'HH:mm' }}</b><small>{{ f.fromCode }}</small></div>
            <div class="r-mid"><small>{{ dur(f.durationMinutes) }}</small><hr><small>{{ f.stops === 0 ? 'Non-stop' : '1 stop' }}</small></div>
            <div class="r-time"><b>{{ f.arrival | date:'HH:mm' }}</b><small>{{ f.toCode }}</small></div>
            <div class="r-price"><b>₹{{ f.price | number:'1.0-0' }}</b><small>per traveller</small></div>
            <a class="btn btn-primary" routerLink="/book/flight/{{ f.id }}" [queryParams]="{ date: params.date, qty: params.pax || 1 }">BOOK</a>
          </div>
        }
      }
    </div>
  `
})
export class FlightsComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(ApiService);
  params: any = {};
  searched = false;
  flights = signal<Flight[]>([]);
  loading = signal(false);
  error = signal('');
  sort = signal<'price' | 'time' | 'duration'>('price');
  dur = duration;

  sorted = computed(() => {
    const l = [...this.flights()];
    const s = this.sort();
    return l.sort((a, b) => s === 'price' ? a.price - b.price : s === 'time' ? a.departure.localeCompare(b.departure) : a.durationMinutes - b.durationMinutes);
  });

  ngOnInit() {
    this.route.queryParams.subscribe(p => {
      this.params = { ...p };
      if (p['from'] && p['to']) {
        this.searched = true; this.loading.set(true); this.error.set('');
        this.api.searchFlights(p['from'], p['to'], p['date'] || isoDate(1)).subscribe({
          next: r => { this.flights.set(r); this.loading.set(false); },
          error: () => { this.error.set('Could not reach the server. Is the API running on port 5000?'); this.loading.set(false); }
        });
      }
    });
  }
}
