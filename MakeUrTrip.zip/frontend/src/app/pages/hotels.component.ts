import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DecimalPipe } from '@angular/common';
import { ApiService } from '../core/api.service';
import { Hotel } from '../core/models';
import { nightsBetween } from '../core/utils';
import { SearchBoxComponent } from '../shared/search-box.component';

@Component({
  selector: 'app-hotels',
  standalone: true,
  imports: [SearchBoxComponent, RouterLink, DecimalPipe],
  template: `
    <section class="hero small"><div class="container"><app-search-box initialTab="hotels" [values]="params" /></div></section>
    <div class="container section">
      @if (loading()) { <p class="muted">Searching hotels…</p> }
      @else if (!searched) { <p class="muted">Choose a city and dates above to search hotels.</p> }
      @else if (error()) { <p class="error">{{ error() }}</p> }
      @else if (hotels().length === 0) { <p class="muted">No hotels found in {{ params.city }}.</p> }
      @else {
        <div class="result-head">
          <h2>Hotels in {{ params.city }} <small>({{ hotels().length }} found • {{ nights }} night(s))</small></h2>
          <div class="sort">Sort:
            <button [class.active]="sort() === 'price'" (click)="sort.set('price')">Price</button>
            <button [class.active]="sort() === 'rating'" (click)="sort.set('rating')">Rating</button>
            <button [class.active]="sort() === 'stars'" (click)="sort.set('stars')">Stars</button>
          </div>
        </div>
        @for (h of sorted(); track h.id) {
          <div class="hotel card">
            <img [src]="h.imageUrl" [alt]="h.name">
            <div class="h-info">
              <h3>{{ h.name }}</h3>
              <div class="stars">{{ '★'.repeat(h.stars) }}<span class="rating">{{ h.rating }}/5</span></div>
              <p class="muted">{{ h.address }}</p>
              <div class="chips">@for (a of h.amenities.split(','); track a) { <span>{{ a }}</span> }</div>
            </div>
            <div class="r-price">
              <b>₹{{ h.pricePerNight | number:'1.0-0' }}</b><small>per night</small>
              <small>Total ₹{{ h.pricePerNight * nights * rooms | number:'1.0-0' }}</small>
              <a class="btn btn-primary" routerLink="/book/hotel/{{ h.id }}"
                 [queryParams]="{ date: params.checkIn, endDate: params.checkOut, qty: rooms, guests: params.guests || 2 }">BOOK</a>
            </div>
          </div>
        }
      }
    </div>
  `
})
export class HotelsComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(ApiService);
  params: any = {};
  searched = false;
  hotels = signal<Hotel[]>([]);
  loading = signal(false);
  error = signal('');
  sort = signal<'price' | 'rating' | 'stars'>('price');
  nights = 1;
  rooms = 1;

  sorted = computed(() => {
    const l = [...this.hotels()];
    const s = this.sort();
    return l.sort((a, b) => s === 'price' ? a.pricePerNight - b.pricePerNight : s === 'rating' ? b.rating - a.rating : b.stars - a.stars);
  });

  ngOnInit() {
    this.route.queryParams.subscribe(p => {
      this.params = { ...p };
      this.rooms = +p['rooms'] || 1;
      this.nights = p['checkIn'] && p['checkOut'] ? Math.max(1, nightsBetween(p['checkIn'], p['checkOut'])) : 1;
      if (p['city']) {
        this.searched = true; this.loading.set(true); this.error.set('');
        this.api.searchHotels(p['city']).subscribe({
          next: r => { this.hotels.set(r); this.loading.set(false); },
          error: () => { this.error.set('Could not reach the server. Is the API running on port 5000?'); this.loading.set(false); }
        });
      }
    });
  }
}
