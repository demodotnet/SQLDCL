import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { DatePipe, DecimalPipe } from '@angular/common';
import { ApiService } from '../core/api.service';
import { Bus } from '../core/models';
import { duration, isoDate } from '../core/utils';
import { SearchBoxComponent } from '../shared/search-box.component';

@Component({
  selector: 'app-buses',
  standalone: true,
  imports: [SearchBoxComponent, RouterLink, DatePipe, DecimalPipe],
  template: `
    <section class="hero small"><div class="container"><app-search-box initialTab="buses" [values]="params" /></div></section>
    <div class="container section">
      @if (loading()) { <p class="muted">Searching buses…</p> }
      @else if (!searched) { <p class="muted">Enter your route above to search buses (e.g. Hyderabad → Bengaluru).</p> }
      @else if (error()) { <p class="error">{{ error() }}</p> }
      @else if (buses().length === 0) { <p class="muted">No buses found for this route. Try Hyderabad ⇄ Bengaluru/Chennai/Pune/Mumbai, Bengaluru ⇄ Goa, Mumbai ⇄ Pune, Delhi ⇄ Jaipur.</p> }
      @else {
        <div class="result-head">
          <h2>{{ params.from }} → {{ params.to }} <small>({{ buses().length }} buses)</small></h2>
          <div class="sort">Sort:
            <button [class.active]="sort() === 'price'" (click)="sort.set('price')">Cheapest</button>
            <button [class.active]="sort() === 'time'" (click)="sort.set('time')">Earliest</button>
          </div>
        </div>
        @for (b of sorted(); track b.id) {
          <div class="result card">
            <div class="r-main"><b>{{ b.operator }}</b><small>{{ b.busType }}</small></div>
            <div class="r-time"><b>{{ b.departure | date:'HH:mm' }}</b><small>{{ b.fromCity }}</small></div>
            <div class="r-mid"><small>{{ dur(b.durationMinutes) }}</small><hr></div>
            <div class="r-time"><b>{{ b.arrival | date:'HH:mm' }}</b><small>{{ b.toCity }}</small></div>
            <div class="r-price"><b>₹{{ b.price | number:'1.0-0' }}</b><small>{{ b.seatsAvailable }} seats left</small></div>
            <a class="btn btn-primary" routerLink="/book/bus/{{ b.id }}" [queryParams]="{ date: params.date, qty: params.pax || 1 }">BOOK</a>
          </div>
        }
      }
    </div>
  `
})
export class BusesComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(ApiService);
  params: any = {};
  searched = false;
  buses = signal<Bus[]>([]);
  loading = signal(false);
  error = signal('');
  sort = signal<'price' | 'time'>('price');
  dur = duration;

  sorted = computed(() => {
    const l = [...this.buses()];
    return l.sort((a, b) => this.sort() === 'price' ? a.price - b.price : a.departure.localeCompare(b.departure));
  });

  ngOnInit() {
    this.route.queryParams.subscribe(p => {
      this.params = { ...p };
      if (p['from'] && p['to']) {
        this.searched = true; this.loading.set(true); this.error.set('');
        this.api.searchBuses(p['from'], p['to'], p['date'] || isoDate(1)).subscribe({
          next: r => { this.buses.set(r); this.loading.set(false); },
          error: () => { this.error.set('Could not reach the server. Is the API running on port 5000?'); this.loading.set(false); }
        });
      }
    });
  }
}
