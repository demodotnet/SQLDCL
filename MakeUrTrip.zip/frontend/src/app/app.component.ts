import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from './core/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <header class="navbar">
      <div class="container nav-inner">
        <a routerLink="/" class="logo">Make<span>Ur</span>Trip</a>
        <nav>
          <a routerLink="/flights" routerLinkActive="active">✈️ Flights</a>
          <a routerLink="/hotels" routerLinkActive="active">🏨 Hotels</a>
          <a routerLink="/buses" routerLinkActive="active">🚌 Buses</a>
        </nav>
        <div class="nav-right">
          @if (auth.user(); as u) {
            <a routerLink="/my-bookings" class="link">My Bookings</a>
            <span class="hello">Hi, {{ u.fullName.split(' ')[0] }}</span>
            <button class="btn btn-outline" (click)="auth.logout()">Logout</button>
          } @else {
            <a routerLink="/login" class="btn btn-outline">Login</a>
            <a routerLink="/register" class="btn btn-primary">Sign up</a>
          }
        </div>
      </div>
    </header>
    <main><router-outlet /></main>
    <footer class="footer">© 2026 MakeUrTrip • Demo travel booking app (ASP.NET Web API + Angular)</footer>
  `
})
export class AppComponent {
  auth = inject(AuthService);
}
