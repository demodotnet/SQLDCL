using MakeUrTrip.Api.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MakeUrTrip.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LookupController : ControllerBase
{
    private readonly AppDbContext _db;
    public LookupController(AppDbContext db) => _db = db;

    [HttpGet("cities")]
    public async Task<ActionResult<List<string>>> Cities() =>
        await _db.Hotels.Select(h => h.City).Distinct().OrderBy(c => c).ToListAsync();
}
