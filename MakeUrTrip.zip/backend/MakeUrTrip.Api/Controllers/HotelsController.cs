using MakeUrTrip.Api.Data;
using MakeUrTrip.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MakeUrTrip.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HotelsController : ControllerBase
{
    private readonly AppDbContext _db;
    public HotelsController(AppDbContext db) => _db = db;

    [HttpGet("search")]
    public async Task<ActionResult<List<Hotel>>> Search([FromQuery] string city)
    {
        var c = city.Trim().ToLower();
        return await _db.Hotels.Where(h => h.City.ToLower() == c).OrderBy(h => h.PricePerNight).ToListAsync();
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Hotel>> Get(int id)
    {
        var h = await _db.Hotels.FindAsync(id);
        return h == null ? NotFound() : Ok(h);
    }
}
