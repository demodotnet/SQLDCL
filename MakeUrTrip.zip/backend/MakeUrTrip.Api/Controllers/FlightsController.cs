using MakeUrTrip.Api.Data;
using MakeUrTrip.Api.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MakeUrTrip.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class FlightsController : ControllerBase
{
    private readonly AppDbContext _db;
    public FlightsController(AppDbContext db) => _db = db;

    [HttpGet("search")]
    public async Task<ActionResult<IEnumerable<FlightDto>>> Search(
        [FromQuery(Name = "from")] string origin,
        [FromQuery(Name = "to")] string destination,
        [FromQuery] DateTime? date)
    {
        var d = (date ?? DateTime.Today).Date;
        var o = origin.Trim().ToLower();
        var t = destination.Trim().ToLower();
        var list = await _db.Flights
            .Where(f => f.FromCity.ToLower() == o && f.ToCity.ToLower() == t)
            .ToListAsync();
        return Ok(list.Select(f => FlightDto.From(f, d)).OrderBy(f => f.Departure));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<FlightDto>> Get(int id, [FromQuery] DateTime? date)
    {
        var f = await _db.Flights.FindAsync(id);
        return f == null ? NotFound() : Ok(FlightDto.From(f, (date ?? DateTime.Today).Date));
    }
}
