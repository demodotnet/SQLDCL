using MakeUrTrip.Api.Data;
using MakeUrTrip.Api.Dtos;
using MakeUrTrip.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MakeUrTrip.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class BookingsController : ControllerBase
{
    private readonly AppDbContext _db;
    public BookingsController(AppDbContext db) => _db = db;

    private int UserId => int.Parse(User.FindFirst("uid")!.Value);

    [HttpPost]
    public async Task<ActionResult<BookingDto>> Create(CreateBookingDto dto)
    {
        if (dto.Passengers == null || dto.Passengers.Count == 0)
            return BadRequest(new { message = "At least one traveller is required." });
        if (dto.Quantity < 1) return BadRequest(new { message = "Quantity must be at least 1." });

        var start = dto.TravelDate.Date;
        if (start < DateTime.Today) return BadRequest(new { message = "Travel date cannot be in the past." });

        var booking = new Booking
        {
            BookingRef = "MUT" + Guid.NewGuid().ToString("N")[..8].ToUpper(),
            UserId = UserId,
            ItemId = dto.ItemId,
            TravelDate = start,
            Quantity = dto.Quantity,
            PaymentMethod = dto.PaymentMethod ?? "UPI",
            ContactEmail = dto.ContactEmail,
            ContactPhone = dto.ContactPhone,
            Status = "Confirmed"
        };

        switch (dto.Type.Trim().ToLower())
        {
            case "flight":
                var f = await _db.Flights.FindAsync(dto.ItemId);
                if (f == null) return NotFound(new { message = "Flight not found." });
                booking.Type = "Flight";
                booking.Title = $"{f.Airline} {f.FlightNumber}";
                booking.Subtitle = $"{f.FromCity} ({f.FromCode}) → {f.ToCity} ({f.ToCode}) • dep {f.DepartureTime:hh\\:mm}";
                booking.TotalAmount = f.Price * dto.Quantity;
                break;

            case "bus":
                var b = await _db.Buses.FindAsync(dto.ItemId);
                if (b == null) return NotFound(new { message = "Bus not found." });
                if (b.SeatsAvailable < dto.Quantity) return BadRequest(new { message = "Not enough seats available." });
                b.SeatsAvailable -= dto.Quantity;
                booking.Type = "Bus";
                booking.Title = $"{b.Operator} ({b.BusType})";
                booking.Subtitle = $"{b.FromCity} → {b.ToCity} • dep {b.DepartureTime:hh\\:mm}";
                booking.TotalAmount = b.Price * dto.Quantity;
                break;

            case "hotel":
                var h = await _db.Hotels.FindAsync(dto.ItemId);
                if (h == null) return NotFound(new { message = "Hotel not found." });
                if (dto.EndDate == null || dto.EndDate.Value.Date <= start)
                    return BadRequest(new { message = "Check-out must be after check-in." });
                var nights = (dto.EndDate.Value.Date - start).Days;
                booking.Type = "Hotel";
                booking.EndDate = dto.EndDate.Value.Date;
                booking.Title = h.Name;
                booking.Subtitle = $"{h.City} • {nights} night(s) • {dto.Quantity} room(s)";
                booking.TotalAmount = h.PricePerNight * nights * dto.Quantity;
                break;

            default:
                return BadRequest(new { message = "Type must be Flight, Hotel or Bus." });
        }

        booking.Passengers = dto.Passengers
            .Select(p => new Passenger { Name = p.Name, Age = p.Age, Gender = p.Gender ?? "" }).ToList();

        _db.Bookings.Add(booking);
        await _db.SaveChangesAsync();
        return Ok(BookingDto.From(booking));
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<BookingDto>>> Mine()
    {
        var list = await _db.Bookings.Include(b => b.Passengers)
            .Where(b => b.UserId == UserId).OrderByDescending(b => b.BookedAt).ToListAsync();
        return Ok(list.Select(BookingDto.From));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<BookingDto>> Get(int id)
    {
        var b = await _db.Bookings.Include(x => x.Passengers).FirstOrDefaultAsync(x => x.Id == id && x.UserId == UserId);
        return b == null ? NotFound() : Ok(BookingDto.From(b));
    }

    [HttpPost("{id:int}/cancel")]
    public async Task<ActionResult<BookingDto>> Cancel(int id)
    {
        var b = await _db.Bookings.Include(x => x.Passengers).FirstOrDefaultAsync(x => x.Id == id && x.UserId == UserId);
        if (b == null) return NotFound();
        if (b.Status == "Cancelled") return BadRequest(new { message = "Already cancelled." });
        if (b.Type == "Bus")
        {
            var bus = await _db.Buses.FindAsync(b.ItemId);
            if (bus != null) bus.SeatsAvailable += b.Quantity;
        }
        b.Status = "Cancelled";
        await _db.SaveChangesAsync();
        return Ok(BookingDto.From(b));
    }
}
