using MakeUrTrip.Api.Data;
using MakeUrTrip.Api.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace MakeUrTrip.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BusesController : ControllerBase
{
    private readonly AppDbContext _db;
    public BusesController(AppDbContext db) => _db = db;

    [HttpGet("search")]
    public async Task<ActionResult<IEnumerable<BusDto>>> Search(
        [FromQuery(Name = "from")] string origin,
        [FromQuery(Name = "to")] string destination,
        [FromQuery] DateTime? date)
    {
        var d = (date ?? DateTime.Today).Date;
        var o = origin.Trim().ToLower();
        var t = destination.Trim().ToLower();
        var list = await _db.Buses
            .Where(b => b.FromCity.ToLower() == o && b.ToCity.ToLower() == t)
            .ToListAsync();
        return Ok(list.Select(b => BusDto.From(b, d)).OrderBy(b => b.Departure));
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<BusDto>> Get(int id, [FromQuery] DateTime? date)
    {
        var b = await _db.Buses.FindAsync(id);
        return b == null ? NotFound() : Ok(BusDto.From(b, (date ?? DateTime.Today).Date));
    }
}
