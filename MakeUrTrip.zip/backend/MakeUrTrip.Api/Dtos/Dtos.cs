using System.ComponentModel.DataAnnotations;
using MakeUrTrip.Api.Models;

namespace MakeUrTrip.Api.Dtos;

public record RegisterDto(
    [Required, MinLength(2)] string FullName,
    [Required, EmailAddress] string Email,
    string? Phone,
    [Required, MinLength(6)] string Password);

public record LoginDto([Required] string Email, [Required] string Password);

public record AuthResponse(string Token, int UserId, string FullName, string Email);

public record FlightDto(int Id, string Airline, string FlightNumber, string FromCity, string FromCode,
    string ToCity, string ToCode, DateTime Departure, DateTime Arrival, int DurationMinutes, double Price, int Stops)
{
    public static FlightDto From(Flight f, DateTime date)
    {
        var dep = date.Date + f.DepartureTime;
        return new FlightDto(f.Id, f.Airline, f.FlightNumber, f.FromCity, f.FromCode, f.ToCity, f.ToCode,
            dep, dep.AddMinutes(f.DurationMinutes), f.DurationMinutes, f.Price, f.Stops);
    }
}

public record BusDto(int Id, string Operator, string BusType, string FromCity, string ToCity,
    DateTime Departure, DateTime Arrival, int DurationMinutes, double Price, int SeatsAvailable)
{
    public static BusDto From(Bus b, DateTime date)
    {
        var dep = date.Date + b.DepartureTime;
        return new BusDto(b.Id, b.Operator, b.BusType, b.FromCity, b.ToCity, dep,
            dep.AddMinutes(b.DurationMinutes), b.DurationMinutes, b.Price, b.SeatsAvailable);
    }
}

public record PassengerDto([Required] string Name, int Age, string Gender);

public record CreateBookingDto(
    [Required] string Type,
    int ItemId,
    DateTime TravelDate,
    DateTime? EndDate,
    int Quantity,
    List<PassengerDto> Passengers,
    [Required, EmailAddress] string ContactEmail,
    [Required] string ContactPhone,
    string? PaymentMethod);

public record BookingDto(int Id, string BookingRef, string Type, string Title, string Subtitle,
    DateTime TravelDate, DateTime? EndDate, int Quantity, double TotalAmount, string Status,
    string PaymentMethod, DateTime BookedAt, List<PassengerDto> Passengers)
{
    public static BookingDto From(Booking b) => new(b.Id, b.BookingRef, b.Type, b.Title, b.Subtitle,
        b.TravelDate, b.EndDate, b.Quantity, b.TotalAmount, b.Status, b.PaymentMethod, b.BookedAt,
        b.Passengers.Select(p => new PassengerDto(p.Name, p.Age, p.Gender)).ToList());
}
