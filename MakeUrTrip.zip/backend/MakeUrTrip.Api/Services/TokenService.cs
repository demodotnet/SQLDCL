using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using MakeUrTrip.Api.Models;
using Microsoft.IdentityModel.Tokens;

namespace MakeUrTrip.Api.Services;

public class TokenService
{
    private readonly IConfiguration _cfg;
    public TokenService(IConfiguration cfg) => _cfg = cfg;

    public string Create(User user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_cfg["Jwt:Key"]!));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var claims = new[]
        {
            new Claim("uid", user.Id.ToString()),
            new Claim("email", user.Email),
            new Claim("name", user.FullName)
        };
        var token = new JwtSecurityToken(_cfg["Jwt:Issuer"], _cfg["Jwt:Audience"], claims,
            expires: DateTime.UtcNow.AddHours(12), signingCredentials: creds);
        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
