using MakeUrTrip.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace MakeUrTrip.Api.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Flight> Flights => Set<Flight>();
    public DbSet<Hotel> Hotels => Set<Hotel>();
    public DbSet<Bus> Buses => Set<Bus>();
    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<Passenger> Passengers => Set<Passenger>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<User>().HasIndex(u => u.Email).IsUnique();
        mb.Entity<Booking>().HasIndex(b => b.BookingRef).IsUnique();
        mb.Entity<Booking>().HasOne<User>().WithMany().HasForeignKey(b => b.UserId);
        mb.Entity<Booking>().HasMany(b => b.Passengers).WithOne().HasForeignKey(p => p.BookingId)
            .OnDelete(DeleteBehavior.Cascade);
        mb.Entity<Flight>().HasIndex(f => new { f.FromCity, f.ToCity });
        mb.Entity<Hotel>().HasIndex(h => h.City);
        mb.Entity<Bus>().HasIndex(b => new { b.FromCity, b.ToCity });
    }
}
