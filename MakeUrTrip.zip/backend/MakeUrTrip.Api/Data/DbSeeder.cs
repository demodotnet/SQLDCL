using MakeUrTrip.Api.Models;

namespace MakeUrTrip.Api.Data;

public static class DbSeeder
{
    public static readonly (string Name, string Code)[] Cities =
    {
        ("Hyderabad", "HYD"), ("Mumbai", "BOM"), ("Delhi", "DEL"), ("Bengaluru", "BLR"),
        ("Chennai", "MAA"), ("Kolkata", "CCU"), ("Goa", "GOI"), ("Pune", "PNQ"),
        ("Jaipur", "JAI"), ("Kochi", "COK")
    };

    public static void Seed(AppDbContext db)
    {
        if (db.Flights.Any()) return;
        var rnd = new Random(42);

        // ---------- Flights ----------
        var airlines = new[] { ("IndiGo", "6E"), ("Air India", "AI"), ("SpiceJet", "SG"), ("Vistara", "UK"), ("Akasa Air", "QP") };
        var hours = new[] { 6, 9, 13, 17, 20 };
        var flights = new List<Flight>();
        foreach (var a in Cities)
            foreach (var b in Cities)
            {
                if (a.Name == b.Name) continue;
                int baseDuration = 70 + rnd.Next(0, 110);
                int basePrice = 2800 + rnd.Next(0, 4200);
                for (int i = 0; i < 4; i++)
                {
                    var al = airlines[rnd.Next(airlines.Length)];
                    flights.Add(new Flight
                    {
                        Airline = al.Item1,
                        FlightNumber = $"{al.Item2}-{rnd.Next(100, 999)}",
                        FromCity = a.Name, FromCode = a.Code,
                        ToCity = b.Name, ToCode = b.Code,
                        DepartureTime = new TimeSpan(hours[rnd.Next(hours.Length)], rnd.Next(0, 12) * 5, 0),
                        DurationMinutes = baseDuration + rnd.Next(-10, 25),
                        Price = basePrice + rnd.Next(-600, 1800),
                        Stops = rnd.Next(0, 10) > 7 ? 1 : 0
                    });
                }
            }
        db.Flights.AddRange(flights);

        // ---------- Hotels ----------
        var templates = new (string Name, int Stars, string Amenities, int Price)[]
        {
            ("Grand {0} Palace", 5, "Free WiFi,Swimming Pool,Spa,Breakfast,Gym", 9500),
            ("{0} Residency", 4, "Free WiFi,Breakfast,Restaurant,Parking", 5200),
            ("Hotel {0} Inn", 3, "Free WiFi,AC,Breakfast", 2800),
            ("{0} Budget Stay", 2, "Free WiFi,AC", 1400)
        };
        foreach (var c in Cities)
        {
            int i = 0;
            foreach (var t in templates)
            {
                db.Hotels.Add(new Hotel
                {
                    Name = string.Format(t.Name, c.Name),
                    City = c.Name,
                    Address = $"{rnd.Next(1, 200)}, Main Road, {c.Name}",
                    Stars = t.Stars,
                    Rating = Math.Round(3.4 + rnd.NextDouble() * 1.5, 1),
                    PricePerNight = t.Price + rnd.Next(-300, 800),
                    Amenities = t.Amenities,
                    ImageUrl = $"https://picsum.photos/seed/{c.Name}{i++}/480/300"
                });
            }
        }

        // ---------- Buses ----------
        var routes = new (string, string)[]
        {
            ("Hyderabad","Bengaluru"), ("Hyderabad","Chennai"), ("Hyderabad","Pune"), ("Hyderabad","Mumbai"),
            ("Bengaluru","Chennai"), ("Bengaluru","Goa"), ("Mumbai","Pune"), ("Mumbai","Goa"),
            ("Delhi","Jaipur"), ("Chennai","Kochi"), ("Bengaluru","Kochi"), ("Pune","Goa")
        };
        var operators = new[] { "VRL Travels", "SRS Travels", "Orange Tours", "Kallada Travels", "IntrCity SmartBus", "Neeta Travels" };
        var types = new[] { "AC Sleeper (2+1)", "Non-AC Seater", "AC Semi Sleeper", "Volvo Multi-Axle AC" };
        var busHours = new[] { 18, 19, 20, 21, 22, 23 };
        foreach (var (a, b) in routes)
            foreach (var (origin, dest) in new[] { (a, b), (b, a) })
            {
                int dur = 360 + rnd.Next(0, 480);
                int price = 600 + rnd.Next(0, 1000);
                for (int i = 0; i < 4; i++)
                    db.Buses.Add(new Bus
                    {
                        Operator = operators[rnd.Next(operators.Length)],
                        BusType = types[rnd.Next(types.Length)],
                        FromCity = origin, ToCity = dest,
                        DepartureTime = new TimeSpan(busHours[rnd.Next(busHours.Length)], rnd.Next(0, 4) * 15, 0),
                        DurationMinutes = dur + rnd.Next(-30, 60),
                        Price = price + rnd.Next(-150, 500),
                        SeatsAvailable = rnd.Next(8, 36)
                    });
            }

        db.SaveChanges();
    }
}
