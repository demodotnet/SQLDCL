namespace MakeUrTrip.Api.Models;

public class User
{
    public int Id { get; set; }
    public string FullName { get; set; } = "";
    public string Email { get; set; } = "";
    public string? Phone { get; set; }
    public string PasswordHash { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public class Flight
{
    public int Id { get; set; }
    public string Airline { get; set; } = "";
    public string FlightNumber { get; set; } = "";
    public string FromCity { get; set; } = "";
    public string FromCode { get; set; } = "";
    public string ToCity { get; set; } = "";
    public string ToCode { get; set; } = "";
    public TimeSpan DepartureTime { get; set; }
    public int DurationMinutes { get; set; }
    public double Price { get; set; }
    public int Stops { get; set; }
}

public class Hotel
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string City { get; set; } = "";
    public string Address { get; set; } = "";
    public int Stars { get; set; }
    public double Rating { get; set; }
    public double PricePerNight { get; set; }
    public string Amenities { get; set; } = "";
    public string ImageUrl { get; set; } = "";
}

public class Bus
{
    public int Id { get; set; }
    public string Operator { get; set; } = "";
    public string BusType { get; set; } = "";
    public string FromCity { get; set; } = "";
    public string ToCity { get; set; } = "";
    public TimeSpan DepartureTime { get; set; }
    public int DurationMinutes { get; set; }
    public double Price { get; set; }
    public int SeatsAvailable { get; set; }
}

public class Booking
{
    public int Id { get; set; }
    public string BookingRef { get; set; } = "";
    public int UserId { get; set; }
    public string Type { get; set; } = "";          // Flight | Hotel | Bus
    public int ItemId { get; set; }
    public string Title { get; set; } = "";
    public string Subtitle { get; set; } = "";
    public DateTime TravelDate { get; set; }         // travel / check-in date
    public DateTime? EndDate { get; set; }           // check-out date (hotels)
    public int Quantity { get; set; }                // passengers / seats / rooms
    public double TotalAmount { get; set; }
    public string Status { get; set; } = "Confirmed"; // Confirmed | Cancelled
    public string PaymentMethod { get; set; } = "UPI";
    public string ContactEmail { get; set; } = "";
    public string ContactPhone { get; set; } = "";
    public DateTime BookedAt { get; set; } = DateTime.UtcNow;
    public List<Passenger> Passengers { get; set; } = new();
}

public class Passenger
{
    public int Id { get; set; }
    public int BookingId { get; set; }
    public string Name { get; set; } = "";
    public int Age { get; set; }
    public string Gender { get; set; } = "";
}
